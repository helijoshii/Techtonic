import React from "react";
import Cards from "../components/Cards";
import coursesData from "../data/coursesData";

const Courses = () => {
  return (
    <>
      <div className="container py-32 px-32">
        <div className="flex flex-col gap-5 items-center ">
          <p className="text-base uppercase font-bold">Courses</p>
          <p className="text-5xl font-bold">What You Will Learn</p>
          <p className="text-base font-medium max-w-[600px] text-center text-custom-grey">
            Tellus nulla lectus faucibus vitae, non sem sollicitudin nunc ipsum
            volutpat dolor nec facilisis pulvinar mus ut egestas ultrices amet,
            ridiculus senectus at.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {coursesData.map((course, index) => (
          <Cards
            key={index}
            image={course.image}
            title={course.title}
            lessons={course.lessons}
            hours={course.hours}
            description={course.description}
          />
        ))}

        </div>


        <div className="py-36">
          <div className="items-center flex flex-col">
            <p  className="text-5xl font-bold">Become Pro in 30 Days</p>
            <p className="text-base pt-5 font-normal text-center max-w-[600px] text-custom-grey">Tellus nulla lectus faucibus vitae, non sem sollicitudin nunc ipsum volutpat dolor nec facilisis pulvinar mus ut egestas ultrices amet, ridiculus senectus at.</p>
          </div>

          <div className="flex items-center justify-center gap-32 pt-28">
            <div >
              <p className="font-semibold text-3xl">Websites Development</p>
              <p className="max-w-72 text-base pt-5 font-normal text-center text-custom-grey">Sed pellentesque eget quis amet amet, proin sed sagittis in ligula semper cursus amet, ullamcorper volutpat rutrum.</p>
            </div>
            <div>
              <p className="font-semibold text-3xl">Apps Development</p>
              <p className="max-w-72 text-base pt-5 font-normal text-center text-custom-grey">Et volutpat at interdum eros et sit augue mattis ut sed elit varius nunc pharetra pellentesque urna cum nullam urna.</p>
            </div>
            <div >
              <p className="font-semibold text-3xl">JAM-Stack</p>
              <p className="max-w-72 text-base pt-5 font-normal text-center text-custom-grey">In nunc gravida aenean ullamcorper cras facilisi amet sit et dolor lorem donec proin fusce lacus, sit enim morbi ut.

</p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Courses;
