// import Code1 from "../assets/code1.jpg";
// import Code2 from "../assets/code2.jpg";

const coursesData = [
  {
    // image: Code1,
    title: "Introduction",
    lessons: 4,
    hours: 2,
    description: "Quis ultricies vestibulum aliquet dolor scelerisque nibh orci adipiscing consectetur diam vel vulputate felis, pretium sociis imperdiet praesent lorem enim donec porttitor.",
  },
  {
    // image: Code2,
    title: "The Basics",
    lessons: 12,
    hours: 20,
    description:
      "Morbi felis massa enim ut vitae egestas purus commodo quis vitae iaculis nullam sit est proin netus amet facilisis mattis tortor, suspendisse elementum facilisi.",
  },
  {
    // image: Code2,
    title: "Working With Data",
    lessons: 28,
    hours: 46,
    description:
      "Blandit blandit amet sollicitudin enim lacus, in mauris lectus leo blandit sagittis blandit lorem diam maecenas tortor morbi sed semper lacus, semper magnis imperdiet.",
  },
  {
    // image: Code2,
    title: "Validating",
    lessons: 16,
    hours: 28,
    description:
      "Lectus nunc, sagittis aliquet interdum lectus eu condimentum lorem etiam mollis tincidunt faucibus auctor elit tempus ac interdum imperdiet elit lectus lorem porttitor tellus.",
  },
  {
    // image: Code2,
    title: "Loops",
    lessons: 10,
    hours: 18,
    description:
      "Est diam scelerisque nulla quis ultrices dui tincidunt pharetra eros, quis nec etiam bibendum ligula ornare tellus pretium odio sed faucibus etiam lobortis ut.",
  },
  {
    // image: Code2,
    title: "Testing",
    lessons: 14,
    hours: 21,
    description:
      "Non faucibus tellus non integer integer ipsum, sit libero, id non malesuada ipsum ornare pellentesque semper egestas sodales non nunc sed nibh duis dui.",
  }

];

export default coursesData;
