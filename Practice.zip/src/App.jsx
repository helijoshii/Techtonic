
import './App.css'
import Courses from './pages/Courses'
import Home from './pages/Home'
import Testimonials from './pages/Testimonials'

function App() {

  return (
    <>
    <div class=" w-full h-fit bg-gradient-to-r from-white from-10% via-[#fdecb1] via-30% to-white to-90% ...">
     <Home />
    </div>
    <Courses />
    <Testimonials />
    </>
  )
}

export default App
