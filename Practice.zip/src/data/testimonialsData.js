// src/data/testimonialsData.js
const testimonialsData = [
    {
      text: "Eget blandit faucibus amet feugiat ante semper mattis quam ornare senectus scelerisque consequat placerat quis a in etiam risus diam viverra mattis tellus.",
      name: "Lisa Hallway",
      title: "VP of Products",
    },
    {
      text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
      name: "John Doe",
      title: "CEO of Example Co.",
    },
    {
      text: "Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
      name: "Jane Smith",
      title: "Marketing Director",
    }
    // Add more testimonials as needed
  ];
  
  export default testimonialsData;
  